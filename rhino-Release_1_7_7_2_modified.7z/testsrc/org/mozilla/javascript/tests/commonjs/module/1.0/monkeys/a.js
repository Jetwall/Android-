require('program').monkey = 10;
