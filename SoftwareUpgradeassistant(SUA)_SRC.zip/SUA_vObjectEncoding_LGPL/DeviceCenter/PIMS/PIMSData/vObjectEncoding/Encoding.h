#if 1

#import <Cocoa/Cocoa.h>
#import "vCardCommon.h"

#pragma once


#define lstrlenA strlen

typedef int CHARSET_T;
namespace CHARSET
{
	const CHARSET_T null			= (CHARSET_T)0;
	
	const CHARSET_T UTF8			= (CHARSET_T)1;
	const CHARSET_T SHIFT_JIS		= (CHARSET_T)2;
	
	const CHARSET_T unknown			= (CHARSET_T)-1;
}

typedef int ENCODING_T;
namespace ENCODING
{
	const ENCODING_T null						= (ENCODING_T)0;
	
	const ENCODING_T QUOTED_PRINTABLE			= (ENCODING_T)1;
	const ENCODING_T BASE64						= (ENCODING_T)2;
	const ENCODING_T QUOTED_PRINTABLE_USE_CR	= (ENCODING_T)3;
	
	const ENCODING_T unknown					= (ENCODING_T)-1;
}

BOOL QPDecode2(BYTE* pbSrcData, 
			   int nSrcLen, 
			   LPSTR szDest, 
			   int* pnDestLen,
			   ENCODING_T encoding,
			   DWORD dwFlags = 0) throw();

BOOL QPEncode2(BYTE* pbSrcData, 
			   int nSrcLen, 
			   LPSTR szDest, 
			   int* pnDestLen, 
			   DWORD dwFlags = 0) throw();

NSMutableString *QPEncode(const NSString *pszSrc);
//NSMutableString *QPEncode(CStringA *pszSrc) ;
NSMutableString *QPEncode(CStringA *pszSrc, int cchSrc);


void QPDecode(CStringA *pszSrc, int cchSrc, CStringA *rString, ENCODING_T encoding);
//void QPDecode(CStringA *pszSrc, int cchSrc, CStringW *rString, ENCODING_T encoding);
inline  void QPDecode(CStringA *pszSrc, CStringA *rString, ENCODING_T encoding) {
	QPDecode(pszSrc, [pszSrc length], rString, encoding);
}
//inline void QPDecode(CStringA *pszSrc, CStringW *rString, ENCODING_T encoding) {
//	QPDecode(pszSrc, [pszSrc length], rString, encoding);
//}

inline CStringW *QPDecode(CStringA *pszSrc, int cchSrc, ENCODING_T encoding) {
	CStringW *str; 
	QPDecode(pszSrc, cchSrc, str, encoding); 
	return str;
}

inline CStringW *QPDecode(CStringA *pszSrc, ENCODING_T encoding) {
	CStringW *str; 
	QPDecode(pszSrc, [pszSrc length], str, encoding); 
	return str;
}

NSMutableString *Decode(const void *pszSrc, int cchSrc, CHARSET_T charset, ENCODING_T encoding);

NSMutableString *EncodeEscapedCharString(CStringA *str);
NSData* DecodeEscapedCharString(const char *buf, size_t len);
NSMutableString* DecodeEscapedCharString(NSString *str);

const LPCSTR szParams_QPEncodedUTF8 = ";CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE";
#define Params_QPEncodedUTF8 @";CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE"
const LPCSTR szParams_QPEncodedUTF8_CUSTOM = "CHARSET=UTF-8,ENCODING=QUOTED-PRINTABLE,";
#define Params_QPEncodedUTF8_CUSTOM @"CHARSET=UTF-8,ENCODING=QUOTED-PRINTABLE,"

inline bool IsQPChanged(const CStringA *str) 
{ 
	NSRange range;
	range = [str rangeOfString:@"="];
	return range.location != NSNotFound; 
}

#define Params_QPEncodedBASE64 @";TYPE=JPEG;ENCODING=BASE64"
const LPCSTR szParams_QPEncodedBASE64 = ";TYPE=JPEG;ENCODING=BASE64";



#endif