

#include "Encoding.h"
//#include "atlenc.h"
#include "NGQuotedPrintableCoding.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#define ATLASSERT assert

//Not including CRLFs
//NOTE: For BASE64 and UUENCODE, this actually
//represents the amount of unencoded characters
//per line


//=======================================================================
// Quoted Printable encode/decode
// compliant with RFC 2045
//=======================================================================
//

inline int Modified_QPEncodeGetRequiredLength(int nSrcLen) throw()
{
	//ASSERT(false);
	int nRet = (int)(3*((3.*nSrcLen)/(ATLSMTP_MAX_QP_LINE_LENGTH-8)));
	nRet += 3*nSrcLen;
	nRet += 3;
	return nRet;
}

BOOL QPDecode2(BYTE* pbSrcData, 
			   int nSrcLen, 
			   LPSTR szDest, 
			   int* pnDestLen, 
			   ENCODING_T encoding,
			   DWORD dwFlags) throw()
{
	if (!pbSrcData || !szDest || !pnDestLen)
	{
		return FALSE;
	}
	
	int nRead = 0, nWritten = 0, nLineLen = -1;
	char ch;
	while (nRead <= nSrcLen)
	{
		ch = *pbSrcData++;
		nRead++;
		nLineLen++;
		if (ch == '=')
		{
			//if the next character is a digit or a character, convert
			if (nRead < nSrcLen && (isdigit(*pbSrcData) || isalpha(*pbSrcData)))
			{
				char szBuf[5];
				szBuf[0] = *pbSrcData++;
				szBuf[1] = *pbSrcData++;
				szBuf[2] = '\0';
				char* tmp = '\0';
				if(ENCODING::QUOTED_PRINTABLE_USE_CR == encoding && 
				   szBuf[0] == '0' && szBuf[1] == 'D')		
					szBuf[1] = 'A';
				*szDest++ = (BYTE)strtoul(szBuf, &tmp, 16);
				nWritten++;
				nRead += 2;
				continue;
			}
			//if the next character is a carriage return or line break, eat it
			if (nRead < nSrcLen && *pbSrcData == '\r' && (nRead+1 < nSrcLen) && *(pbSrcData+1)=='\n')
			{
				pbSrcData++;
				nRead++;
				nLineLen = -1;
				continue;
			}
			
			if (nRead > nSrcLen)
				ch = NULL;
			else
				return FALSE;
		}
		if (ch == '\r' || ch == '\n')
		{
			nLineLen = -1;
			continue;
		}
		if ((dwFlags & ATLSMTP_QPENCODE_DOT) && ch == '.' && nLineLen == 0)
		{
			continue;
		}
		*szDest++ = ch;
		nWritten++;
	}
	
	*pnDestLen = nWritten-1;
	return TRUE;
}

static char *_itoa(unsigned i, char *a, unsigned r) /* private fn */ 
{ 
	if (i/r > 0) a = _itoa(i/r,a,r); 
	*a = "0123456789ABCDEF"[i%r]; 
	return a+1; 
} 

char *itoa(int i, char *a, int r)                 /* public fn */ 
{ 
	if ((r < 2) || (r > 16)) r = 10; 
	if (i < 0) 
	{ 
		*a = '-'; 
		*_itoa(-i,a+1,r) = 0; 
		*_itoa(-(unsigned)i,a+1,r) = 0; 
		//		to avoid undefined behaviour for i < -INT_MAX. 
	} 
	else *_itoa(i,a,r) = 0; 
	return a; 
} 

BOOL QPEncode2(BYTE* pbSrcData, 
			   int nSrcLen, 
			   LPSTR szDest, 
			   int* pnDestLen, 
			   DWORD dwFlags) throw()
{
	//The hexadecimal character set
	static const char s_chHexChars[16] = {
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
		'A', 'B', 'C', 'D', 'E', 'F'
	};
	
	if (!pbSrcData || !szDest || !pnDestLen)
	{
		return FALSE;
	}
	
	assert(*pnDestLen >= QPEncodeGetRequiredLength(nSrcLen));
	
	int nRead = 0, nWritten = 0, nLineLen = 0;
	char ch;
	while (nRead < nSrcLen)
	{
		ch = *pbSrcData++;
		nRead++;
		if (nLineLen == 0 && ch == '.' && (dwFlags & ATLSMTP_QPENCODE_DOT))
		{
			*szDest++ = '.';
			nWritten++;
			nLineLen++;
		}
		if ((ch == 40 || ch == 41 || ch == 58 || ch == 59))
		{
			char str[5]  = {0};
			
			itoa(ch , str , 16);
			
			*szDest++ = '=';
			*szDest++ = str[0];
			*szDest++ = str[1];
			nWritten += 3;
			nLineLen += 3;
			
		}
		else if (ch > 32 && ch < 127 && ch != '=')
		{
			*szDest++ = ch;
			nWritten++;
			nLineLen++;
		}
		else if ((ch == ' ' || ch == '\t') && (nLineLen < (ATLSMTP_MAX_QP_LINE_LENGTH-12)))
		{
			*szDest++ = ch;
			nWritten++;
			nLineLen++;
		}	
		else
		{
			*szDest++ = '=';
			*szDest++ = s_chHexChars[(ch >> 4) & 0x0F];
			*szDest++ = s_chHexChars[ch & 0x0F];
			nWritten += 3;
			nLineLen += 3;
		}
		if (nLineLen >= (ATLSMTP_MAX_QP_LINE_LENGTH-8) && nRead < nSrcLen)//-11
		{
			*szDest++ = '=';
			*szDest++ = '\r';
			*szDest++ = '\n';
			nLineLen = 0;
			nWritten += 3;
		}
	}
	if (dwFlags & ATLSMTP_QPENCODE_TRAILING_SOFT)
	{
		*szDest++ = '=';
		*szDest++ = '\r';
		*szDest++ = '\n';
		nWritten += 3;
	}
	
	ATLASSERT(*pnDestLen >= nWritten);
	*pnDestLen = nWritten;
	
	return TRUE;
}

NSMutableString *QPEncode(CStringA *pszSrc) 
{
	const char* bufferStr = [pszSrc UTF8String];
	if(pszSrc != nil){
		return QPEncode(pszSrc, strlen(bufferStr));
	}
	else{
		return [NSMutableString stringWithString:@""];
	}
} 

NSMutableString *QPEncode(const NSString *pszSrc)
{
    return QPEncode((CStringA*)[pszSrc mutableCopy]);
}

NSMutableString *QPEncode(CStringA *pszSrc, int cchSrc)
{
	int cchDst = QPEncodeGetRequiredLength(cchSrc);
	char* pszDst = (char*)malloc(cchDst+1);
	QPEncode2((BYTE*)[pszSrc UTF8String], cchSrc, pszDst, &cchDst);
	pszDst[cchDst] = NULL;
	NSMutableString* retStr = [NSMutableString stringWithUTF8String:pszDst];
	free(pszDst);
	return retStr;
}


NSMutableString *QPEncode(LPCWSTR pszSrc, int cchSrc)
{
	NSMutableString *temp = [NSString stringWithUTF8String:pszSrc];
	return [temp stringByEncodingQuotedPrintable];
}

#pragma mark -

void QPDecode(LPCSTR pszSrc, int cchSrc, CStringA *rString, ENCODING_T encoding)
{
}


NSMutableString *Decode(const void *pszSrc, int cchSrc, CHARSET_T charset, ENCODING_T encoding)
{
	NSMutableString *str;
	NSStringEncoding codepage;
	
	switch (charset)
	{
		case CHARSET::UTF8:
			codepage = NSUTF8StringEncoding;
			break;
			
		case CHARSET::SHIFT_JIS:
			codepage = NSShiftJISStringEncoding/*Japanese (Shift-JIS)*/;
			break;
			
		case CHARSET::unknown:
		default:
			//		SUPERASSERT("지원하지 않는 charset.");
			codepage = NSUTF8StringEncoding;
			break;
	}
	
	switch (encoding)
	{
		case ENCODING::null:
			str = [[[NSMutableString alloc] initWithBytes:pszSrc length:cchSrc encoding:codepage] autorelease];
			break;
			
		case ENCODING::QUOTED_PRINTABLE:
		case ENCODING::QUOTED_PRINTABLE_USE_CR:
			QPDecode((LPCSTR)pszSrc, cchSrc, str, encoding);
			str = [NSMutableString stringByDecodingQuotedPrintable:(const char*)pszSrc length:cchSrc encoding:codepage];
			break;
			
		case ENCODING::BASE64:
			str = [[[NSMutableString alloc] initWithBytes:pszSrc length:cchSrc encoding:codepage] autorelease];
			//		SUPERASSERT(!"BASE64를 아직 지원하지 않습니다.");
			break;
			
		default:
			str = [[[NSMutableString alloc] initWithBytes:pszSrc length:cchSrc encoding:codepage] autorelease];
			//		SUPERASSERT(!"지원하지 않는 encoding.");
	}
	
	return str;
}


NSMutableString *EncodeEscapedCharString(CStringA *str)
{
	int cch = [str length];
	unichar *pszTmp = (unichar*)malloc(cch * sizeof(unichar) * 2  + 1 * sizeof(unichar));
	unichar* pChar = pszTmp;
	int len = 0;
	NSMutableString *temp;
	
	
	for (int i = 0; i < cch; ++i)
	{
		if ([str characterAtIndex:i] == '\\' || [str characterAtIndex:i] == ';')
		{
			*pChar++ = '\\';
			len++;
		}
		
		*pChar++ =[str characterAtIndex:i];
		len++;
	}
	*pChar = NULL;
	
	temp = [[[NSMutableString alloc] initWithCharacters:pszTmp length:len] autorelease];	
	
	free(pszTmp);
	
	return temp;
}


NSData* DecodeEscapedCharString(const char *buf, size_t len)
{
	LPSTR pszTmp = (LPSTR)malloc(len + 1);
	char* pChar = pszTmp;
	char ch;
	
	memset(pszTmp, 0x00, len + 1);
	
	for (int i = 0; i < len; ++i)
	{
		ch = buf[i];
		if (ch == '\\')
		{
			++i;
			
			if (ch == ';')
				*pChar++ = ';';
			else if (ch == '\\')
				*pChar++ = '\\';
			else
			{
				*pChar++ = '\\';
				*pChar++ = (char)ch;
			}
		}
		else
		{
			*pChar++ = (char)ch;
		}
	}
	*pChar = NULL;
	
	NSData *data = [[[NSData alloc] initWithBytes:pszTmp length:strlen(pszTmp)] autorelease];
	
	free(pszTmp);
	
	return data;
}

NSMutableString* DecodeEscapedCharString(NSString *str)
{
	int cch = [str length];
	unichar *pszTmp = (unichar*)malloc(cch * sizeof(unichar) + 1 * sizeof(unichar));
	unichar* pChar = pszTmp;
	unichar unich;
	int len= 0;
	
	for (int i = 0; i < cch; ++i)
	{
		unich = [str characterAtIndex:i];
		if (unich == '\\')
		{
			++i;
			
			if (unich == ';') {
				*pChar++ = ';';
				len++;
			}
			else if (unich == '\\') {
				*pChar++ = '\\';
				len++;
			}
			else
			{
				*pChar++ = '\\';
				len++;
				*pChar++ = (char)unich;
				len++;
			}
		}
		else
		{
			*pChar++ = (char)unich;
			len++;
		}
	}
	*pChar = NULL;
	
	NSMutableString *decodedStr = [[[NSMutableString alloc] initWithCharacters:pszTmp length:len] autorelease];
	
	free(pszTmp);
	
	return decodedStr;
}
