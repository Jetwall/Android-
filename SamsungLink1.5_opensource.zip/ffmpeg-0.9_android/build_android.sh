#!/bin/bash


NDK=~/android-ndk-r5b
PLATFORM=$NDK/platforms/android-8/arch-arm
#PREBUILT=$NDK/toolchains/arm-eabi-4.4.0/prebuilt/windows
PREBUILT=$NDK/toolchains/arm-eabi-4.4.0/prebuilt/linux-x86

NATIVE_PATH=./out
mkdir $NATIVE_PATH
rm -r $NATIVE_PATH/android
mkdir $NATIVE_PATH/android

function build_armv7_neon
{

CPU=armv7-a
OPTIMIZE_CFLAGS="-mfloat-abi=softfp -mfpu=neon -marm -march=$CPU -mtune=cortex-a8 -DDEBUG"


SO_PATH=$NATIVE_PATH/android/$CPU
mkdir $SO_PATH

make -j8

$PREBUILT/bin/arm-eabi-ar d libavcodec/libavcodec.a inverse.o
$PREBUILT/bin/arm-eabi-ld -rpath-link=$PLATFORM/usr/lib -L$PLATFORM/usr/lib -shared -nostdlib  -z,noexecstack -Bsymbolic --whole-archive --no-undefined -o $SO_PATH/libASP15_ffmpeg_neon.so libavcodec/libavcodec.a libavformat/libavformat.a libswscale/libswscale.a libavutil/libavutil.a -lc -lm -lz -ldl -llog  --warn-once  --dynamic-linker=/system/bin/linker $PREBUILT/lib/gcc/arm-eabi/4.4.0/libgcc.a 

$PREBUILT/bin/arm-eabi-strip $SO_PATH/libASP15_ffmpeg_neon.so
}
		
make clean
build_armv7_neon


