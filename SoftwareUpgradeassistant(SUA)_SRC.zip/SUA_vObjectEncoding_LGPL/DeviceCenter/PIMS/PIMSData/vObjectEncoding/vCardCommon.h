/*
 *  vCardCommon.h
 *  KiesMini
 *
 *  Created by 박진희 on 10. 8. 17..
 *  Copyright 2010 BeyondTech, Inc. All rights reserved.
 *
 */
#import <Cocoa/Cocoa.h>

const int UndefinedID = -1;
typedef NSMutableArray CStringArray;
typedef NSMutableArray CUIntArray;
typedef NSMutableString CStringA;
typedef NSMutableString CStringW;
typedef const char* LPCWSTR;

typedef uint8_t		BYTE;
typedef uint32_t	DWORD;
typedef const char*	LPCSTR;
typedef char*		LPSTR;

typedef int STORAGE_T;
namespace STORAGE
{
	const STORAGE_T null	= 0x00;
	const STORAGE_T me		= 0x01;
	const STORAGE_T sim		= 0x02;
	const STORAGE_T ph		= 0x03;
	const STORAGE_T pc		= 0x04;
	const STORAGE_T sim2	= 0x05;
}
