1. Original LGPL FFmpeg source code
 http://www.ffmpeg.org/releases/ffmpeg-0.9.tar.bz2

2. Modified LGPL FFmpeg source code
 libavformat/mov.c ; orientation hint�� ���� rotation ��� Ȯ��

3. Build scripts
 libavutil/avconfig.h
 config.h
 config.mak
 build_android.sh

4. Build Environment
 Linux Ubuntu 10.04 : http://releases.ubuntu.com/lucid/
 Android NDK r5b : http://dl.google.com/android/ndk/android-ndk-r5b-linux-x86.tar.bz2

5. How to build
 (1) Download original FFmpeg source codes from [1]
 (2) Overwrite modified FFmpeg source codes with [2]
 (3) Copy build scripts from [3]
 (4) Modify Android NDK paths in [3]
   - config.mak
     NDK=/home/Song/android-ndk-r5b

   - build_android.sh
     NDK=~/android-ndk-r5b

 (5) Run build_android.sh
     ./build_android.sh
 (6) Output file is in ./out/android/armv7-a/
