#!/bin/sh
#./configure --prefix=$HOME/local
make CFLAGS="-m32 -mmacosx-version-min=10.5 -no_compact_linkedit" CXXFLAGS="-m32 -mmacosx-version-min=10.5 -no_compact_linkedit" LDFLAGS="-m32 -mmacosx-version-min=10.5"
