/******************************************************************************
 * Copyright © 2010 LiMo Foundation.
 * Copyright (c) 2009-10 onwards Azingo, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Modification history:
 * 2010, 2011 - Samsung Electronics Inc. - adaptation to WAC SDK
 ******************************************************************************/
package com.samsung.android.sdk.manager.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;

/**
 * Zipping tool. Adapted from BONDI SDK.
 *
 * @author Adam Kotwasinski, Samsung Electronics
 */
public class ZipUtility {

	public static void unzipArchive(File targetArchive, File sourceFile) throws ZipException, IOException {
		inflateZipArchive(sourceFile, targetArchive);
	}

	private static void inflateZipArchive(File targetDirectory, File sourceArchive) throws ZipException, IOException {

		ZipFile zipFile = new ZipFile(sourceArchive);
		Enumeration<? extends ZipEntry> entries = zipFile.entries();

		try {
			while (entries.hasMoreElements()) {
				ZipEntry zipEntry = entries.nextElement();

				IPath filePath = new Path(targetDirectory.getAbsolutePath()).append(zipEntry.getName());
				File file = filePath.toFile();

				// Ignoring directories, these will be created when files within appear.
				if (!zipEntry.isDirectory()) {
					// IPath directoryPath = new
					// Path(targetDirectory.getAbsolutePath()).append(zipEntry.getName());
					// File targetFile = directoryPath.toFile();
					// File targetFile = new File(targetDirectory + "/" +
					// zipEntry.getName());
					File pFile = file.getParentFile();
					if (pFile != null) {
						pFile.mkdirs();
						if (pFile.exists() == false) {
							throw new IOException("Unable to create target directory: " + pFile.getAbsolutePath());
						}
					}
					FileOutputStream targetStream = new FileOutputStream(file);
					copyInputStream(zipFile.getInputStream(zipEntry), targetStream);
				}
			}
		}
		finally {
			try {
				if (zipFile != null) {
					zipFile.close();
				}
			}
			catch (IOException ignored) {
				// Ignore errors during close
			}
		}
	}

	public static final void copyInputStream(InputStream in, OutputStream out) throws IOException {
		try {
			int available = in.available();
			if (available > 4 * 1024) { // 4KB
				available = 4 * 1024;
			}
			byte[] buffer = new byte[available];
			int len;

			while ((len = in.read(buffer)) >= 0) {
				out.write(buffer, 0, len);
			}

		}
		finally {
			try {
				in.close();
			}
			catch (IOException ignored) {
				// ignore errors during close
			}

			try {
				out.close();
			}
			catch (IOException ignored) {
				// ignore errors during close
			}
		}
	}

}
